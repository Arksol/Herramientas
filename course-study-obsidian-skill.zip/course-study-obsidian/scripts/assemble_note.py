#!/usr/bin/env python3
"""Ensambla una nota Markdown con un resumen ya generado y capturas locales."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


INVALID_WINDOWS = re.compile(r'[<>:"/\\|?*]')


def safe_name(value: str) -> str:
    cleaned = INVALID_WINDOWS.sub("-", value).strip().rstrip(".")
    return re.sub(r"\s+", " ", cleaned) or "Clase"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metadata", required=True, type=Path)
    parser.add_argument("--summary", required=True, type=Path)
    parser.add_argument("--captures", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    metadata = json.loads(args.metadata.read_text(encoding="utf-8"))
    summary = args.summary.read_text(encoding="utf-8").strip()

    lesson = safe_name(str(metadata.get("lesson", "Clase")))
    module_number = int(metadata.get("lesson_number", 1))
    filename = f"{module_number:02d}-{lesson}.md"

    args.output_dir.mkdir(parents=True, exist_ok=True)
    output = args.output_dir / filename

    frontmatter = [
        "---",
        "tipo: resumen-clase",
        f"plataforma: {metadata.get('platform', '')}",
        f"curso: {metadata.get('course', '')}",
        f"modulo: {metadata.get('module', '')}",
        f"leccion: {metadata.get('lesson', '')}",
        f"profesor: {metadata.get('teacher', '')}",
        f"fecha: {metadata.get('date', '')}",
        f"duracion: {metadata.get('duration', '')}",
        f"fuente_url: {metadata.get('source_url', '')}",
        "tags:",
        "  - estudio",
        "  - resumen",
        "---",
        "",
        f"# {metadata.get('lesson', 'Clase')}",
        "",
        summary,
    ]

    if args.captures and args.captures.exists():
        images = sorted(
            list(args.captures.glob("*.png"))
            + list(args.captures.glob("*.jpg"))
            + list(args.captures.glob("*.webp"))
        )
        if images:
            frontmatter.extend(["", "## Capturas relevantes", ""])
            for image in images:
                relative = image.as_posix()
                frontmatter.append(f"![[{relative}]]")
                frontmatter.append("")

    output.write_text("\n".join(frontmatter).rstrip() + "\n", encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
