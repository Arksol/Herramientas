#!/usr/bin/env python3
"""Genera un archivo JSON Canvas a partir de conceptos y relaciones."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--note-file", default="")
    args = parser.parse_args()

    data = json.loads(args.input.read_text(encoding="utf-8"))
    concepts = data.get("concepts", [])
    relations = data.get("relations", [])

    nodes = []
    edges = []
    id_map = {}

    if args.note_file:
        nodes.append({
            "id": "nota-principal",
            "type": "file",
            "x": 0,
            "y": 0,
            "width": 420,
            "height": 520,
            "file": args.note_file.replace("\\", "/"),
        })

    columns = 3
    start_x = 560
    start_y = 0
    gap_x = 420
    gap_y = 260

    for index, concept in enumerate(concepts):
        concept_id = str(concept.get("id") or f"concepto-{index + 1}")
        node_id = f"node-{index + 1}"
        id_map[concept_id] = node_id
        row, column = divmod(index, columns)
        label = str(concept.get("label", concept_id))
        explanation = str(concept.get("explanation", "")).strip()
        text = f"## {label}"
        if explanation:
            text += f"\n\n{explanation}"
        nodes.append({
            "id": node_id,
            "type": "text",
            "x": start_x + column * gap_x,
            "y": start_y + row * gap_y,
            "width": 340,
            "height": 190,
            "text": text,
        })

    for index, relation in enumerate(relations):
        source = id_map.get(str(relation.get("from")))
        target = id_map.get(str(relation.get("to")))
        if not source or not target:
            continue
        edge = {
            "id": f"edge-{index + 1}",
            "fromNode": source,
            "fromSide": "right",
            "toNode": target,
            "toSide": "left",
            "toEnd": "arrow",
        }
        label = str(relation.get("label", "")).strip()
        if label:
            edge["label"] = label
        edges.append(edge)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps({"nodes": nodes, "edges": edges}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
