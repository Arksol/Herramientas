$ErrorActionPreference = "Stop"

$SkillSource = Split-Path -Parent $PSScriptRoot
$SkillDestination = Join-Path $HOME ".codex\skills\course-study-obsidian"
$Workspace = Join-Path $HOME "Documents\course-study-agent"

Write-Host "Instalando skill en: $SkillDestination"
New-Item -ItemType Directory -Force (Split-Path -Parent $SkillDestination) | Out-Null
if (Test-Path $SkillDestination) {
    Remove-Item $SkillDestination -Recurse -Force
}
Copy-Item $SkillSource $SkillDestination -Recurse -Force

Write-Host "Preparando espacio de trabajo en: $Workspace"
New-Item -ItemType Directory -Force $Workspace | Out-Null
Set-Location $Workspace

if (-not (Test-Path ".venv")) {
    py -m venv .venv
}

& ".\.venv\Scripts\python.exe" -m pip install --upgrade pip
& ".\.venv\Scripts\python.exe" -m pip install -r `
    (Join-Path $SkillDestination "requirements.txt")

$ConfigPath = Join-Path $Workspace "config.yaml"
if (-not (Test-Path $ConfigPath)) {
    Copy-Item (Join-Path $SkillDestination "config.example.yaml") $ConfigPath
}

Write-Host ""
Write-Host "Instalación terminada."
Write-Host "1. Edita: $ConfigPath"
Write-Host "2. Reinicia Codex."
Write-Host "3. Abre en Codex la carpeta: $Workspace"
