#!/usr/bin/env python3
"""Captura cambios visuales significativos de una región de pantalla.

Uso autorizado únicamente. No evade DRM ni descarga transmisiones.
"""

from __future__ import annotations

import argparse
import json
import signal
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    import imagehash
    import mss
    from PIL import Image
except ImportError as exc:
    raise SystemExit(
        "Faltan dependencias. Ejecuta: pip install -r requirements.txt"
    ) from exc


STOP = False


def stop_handler(signum, frame):
    del signum, frame
    global STOP
    STOP = True


def parse_region(value: str) -> dict[str, int]:
    try:
        left, top, width, height = [int(part.strip()) for part in value.split(",")]
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "La región debe tener formato izquierda,arriba,ancho,alto"
        ) from exc
    if width <= 0 or height <= 0:
        raise argparse.ArgumentTypeError("Ancho y alto deben ser positivos.")
    return {"left": left, "top": top, "width": width, "height": height}


def main() -> int:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--region", type=parse_region)
    group.add_argument("--region-file", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--interval", type=float, default=3.0)
    parser.add_argument("--threshold", type=int, default=10)
    parser.add_argument("--max-captures", type=int, default=40)
    parser.add_argument("--duration-minutes", type=float, default=0)
    args = parser.parse_args()

    if args.interval < 0.5:
        parser.error("--interval debe ser al menos 0.5 segundos.")
    if args.threshold < 0:
        parser.error("--threshold no puede ser negativo.")
    if args.max_captures <= 0:
        parser.error("--max-captures debe ser positivo.")

    if args.region_file:
        try:
            args.region = json.loads(args.region_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, KeyError) as exc:
            raise SystemExit(f"No se pudo leer la región: {exc}") from exc
        required = {"left", "top", "width", "height"}
        if not required.issubset(args.region):
            raise SystemExit("El archivo de región no contiene left, top, width y height.")

    args.output.mkdir(parents=True, exist_ok=True)
    log_path = args.output / "captures.json"
    captures: list[dict[str, object]] = []
    previous_hash = None
    started = time.monotonic()

    signal.signal(signal.SIGINT, stop_handler)
    signal.signal(signal.SIGTERM, stop_handler)

    print("Captura iniciada. Presiona Ctrl+C para detener.")
    print(f"Región: {args.region}")

    with mss.mss() as screen:
        while not STOP and len(captures) < args.max_captures:
            if args.duration_minutes > 0:
                elapsed_minutes = (time.monotonic() - started) / 60
                if elapsed_minutes >= args.duration_minutes:
                    break

            shot = screen.grab(args.region)
            image = Image.frombytes(
                "RGB",
                (shot.width, shot.height),
                shot.rgb,
            )
            current_hash = imagehash.phash(image)

            distance = None if previous_hash is None else current_hash - previous_hash
            should_save = previous_hash is None or distance >= args.threshold

            if should_save:
                index = len(captures) + 1
                timestamp = datetime.now().astimezone()
                filename = f"{index:03d}-{timestamp.strftime('%H%M%S')}.png"
                destination = args.output / filename
                image.save(destination, format="PNG", optimize=True)
                record = {
                    "index": index,
                    "filename": filename,
                    "captured_at": timestamp.isoformat(timespec="seconds"),
                    "hash_distance": distance,
                }
                captures.append(record)
                log_path.write_text(
                    json.dumps(captures, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )
                print(f"Guardada: {filename} | cambio={distance}")
                previous_hash = current_hash

            time.sleep(args.interval)

    print(f"Finalizado. Capturas guardadas: {len(captures)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
