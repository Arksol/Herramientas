#!/usr/bin/env python3
"""Permite seleccionar visualmente una región de pantalla y guardarla en JSON."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import tkinter as tk

try:
    import mss
    from PIL import Image, ImageTk
except ImportError as exc:
    raise SystemExit(
        "Faltan dependencias. Ejecuta: pip install -r requirements.txt"
    ) from exc


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("region.json"))
    args = parser.parse_args()

    with mss.mss() as screen:
        monitor = screen.monitors[0]
        shot = screen.grab(monitor)
        image = Image.frombytes("RGB", (shot.width, shot.height), shot.rgb)

    window = tk.Tk()
    window.title("Selecciona el área de diapositivas")
    window.attributes("-fullscreen", True)
    window.attributes("-topmost", True)

    canvas = tk.Canvas(window, cursor="cross", highlightthickness=0)
    canvas.pack(fill=tk.BOTH, expand=True)

    photo = ImageTk.PhotoImage(image)
    canvas.create_image(0, 0, image=photo, anchor=tk.NW)

    start = {"x": 0, "y": 0}
    rect_id = {"value": None}

    def mouse_down(event):
        start["x"], start["y"] = event.x, event.y
        if rect_id["value"] is not None:
            canvas.delete(rect_id["value"])
        rect_id["value"] = canvas.create_rectangle(
            event.x, event.y, event.x, event.y, outline="red", width=3
        )

    def mouse_move(event):
        if rect_id["value"] is not None:
            canvas.coords(
                rect_id["value"], start["x"], start["y"], event.x, event.y
            )

    def mouse_up(event):
        x1, x2 = sorted((start["x"], event.x))
        y1, y2 = sorted((start["y"], event.y))
        width, height = x2 - x1, y2 - y1
        if width < 50 or height < 50:
            return

        region = {
            "left": monitor["left"] + x1,
            "top": monitor["top"] + y1,
            "width": width,
            "height": height,
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(region, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(args.output.resolve())
        window.destroy()

    def cancel(event=None):
        del event
        window.destroy()

    canvas.bind("<ButtonPress-1>", mouse_down)
    canvas.bind("<B1-Motion>", mouse_move)
    canvas.bind("<ButtonRelease-1>", mouse_up)
    window.bind("<Escape>", cancel)
    window.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
