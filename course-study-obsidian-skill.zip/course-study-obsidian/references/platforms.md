# Adaptadores de plataformas

Las interfaces pueden cambiar. Utilizar etiquetas semánticas y texto visible, no selectores rígidos cuando sea posible.

## Tabla de políticas

| Plataforma | Página inicial sugerida | Resumen | Capturas | Descargar video |
|---|---|---:|---:|---:|
| EBAC | `https://lms.ebac.mx/dashboard` | Sí | Sí, cuando esté permitido | Solo opción oficial |
| UVM Blackboard | Configurable | Sí | Sí, cuando esté permitido | Solo opción oficial |
| Platzi | `https://platzi.com/home` | Sí | Sí, cuando esté permitido | Nunca |
| Coursera | `https://www.coursera.org/my-learning` | Sí | Sí, cuando esté permitido | Nunca |
| Mastermind | `https://mastermind.com` | Sí | Sí, cuando esté permitido | Nunca |

## EBAC

Ruta habitual:

1. Dashboard.
2. Curso activo.
3. Módulo o unidad.
4. Clase.
5. Grabación, materiales, tareas o recursos.

Recopilar:

- Nombre de curso, módulo y clase.
- Texto de la página.
- Descripción y objetivos.
- Transcripción o subtítulos, si están disponibles.
- Recursos y archivos.
- Duración y estado de progreso.
- Capturas de conceptos, diagramas, código y ejemplos.

Descarga:

- Buscar únicamente opciones visibles de descarga.
- Descargar solo cuando la plataforma ofrezca expresamente el archivo.
- Si el reproductor solo permite streaming, registrar `sin-opcion-oficial`.

## UVM Blackboard

La URL depende de la configuración institucional. Definirla en `config.yaml`.

Ruta habitual:

1. Inicio o flujo de actividad.
2. Cursos.
3. Curso correspondiente.
4. Contenido del curso.
5. Módulo o semana.
6. Clase, grabación, recurso o actividad.

También revisar, cuando sean relevantes:

- Anuncios.
- Calendario.
- Descripción del módulo.
- Archivos adjuntos.
- Presentaciones y PDFs.
- Enlaces a bibliotecas de video integradas.

Descarga:

- Un archivo adjunto descargable puede guardarse.
- Un video puede descargarse solamente si Blackboard o el proveedor integrado muestra una opción oficial.
- No usar herramientas de desarrollador para localizar archivos ocultos.
- No exportar el curso completo; esa función suele ser administrativa o docente.

## Platzi

Ruta habitual:

1. Inicio.
2. Mis cursos o ruta de aprendizaje.
3. Curso.
4. Módulo.
5. Clase.
6. Recursos, archivos, lecturas, discusiones o notas.

Recopilar:

- Título y duración.
- Texto y descripción.
- Recursos descargables.
- Código y enlaces.
- Preguntas relevantes de discusión.
- Transcripción o subtítulos visibles.

Política:

- No descargar videos.
- El modo offline oficial pertenece a la aplicación de Platzi y debe gestionarlo el usuario dentro de la aplicación.

## Coursera

Ruta habitual:

1. My Learning.
2. Curso.
3. Módulo o semana.
4. Video, lectura, cuestionario o tarea.
5. Transcript, Downloads o Resources cuando aparezcan.

Recopilar:

- Objetivos del módulo.
- Transcripción oficial.
- Lecturas.
- Archivos del curso.
- Fórmulas, tablas y ejemplos.
- Instrucciones de tareas, evitando resolver evaluaciones calificadas en lugar del estudiante.

Política:

- No descargar videos con el agente.
- El acceso offline oficial, cuando esté disponible, debe realizarse dentro de las aplicaciones oficiales.
- Sí se pueden guardar archivos que el curso presente expresamente como descargables.

## Mastermind

Este adaptador supone `mastermind.com`. Si la cuenta usa otra plataforma denominada Mastermind, cambiar el dominio en `config.yaml`.

Ruta habitual:

1. Iniciar sesión.
2. Learning Center o Learn.
3. Courses.
4. Curso.
5. Lección.
6. Materiales, enlaces, plantillas o recursos.

Recopilar:

- Título de la lección.
- Descripción.
- Texto visible.
- Recursos.
- Ejercicios y acciones.
- Transcripción o subtítulos visibles.

Política:

- No descargar videos.
- No copiar materiales completos para redistribución.
