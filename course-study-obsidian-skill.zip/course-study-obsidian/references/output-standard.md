# Estándar de salida

## Calidad mínima

Una nota completa debe permitir comprender la clase sin sustituir el material original.

Debe incluir:

1. Metadatos verificables.
2. Objetivos.
3. Resumen ejecutivo de 5 a 10 líneas.
4. Desarrollo por temas.
5. Definiciones y ejemplos.
6. Fórmulas o código relevantes.
7. Capturas con leyenda.
8. Diagrama Mermaid.
9. Mapa conceptual Canvas.
10. Preguntas de recuperación activa.
11. Ejercicio práctico.
12. Fuentes utilizadas.
13. Limitaciones.

## Reglas de síntesis

- Eliminar repeticiones y muletillas.
- Conservar advertencias, excepciones y procedimientos.
- Explicar términos técnicos con lenguaje sencillo.
- No atribuir al profesor información añadida por el agente.
- Marcar claramente las explicaciones complementarias.
- No copiar transcripciones completas salvo necesidad y autorización.
- No resolver evaluaciones calificadas de forma deshonesta.

## Capturas

Cada captura debe tener:

- Nombre descriptivo.
- Minuto aproximado, si se conoce.
- Una leyenda de una oración.
- Relación directa con el texto cercano.

## Fórmulas

Para cada fórmula:

- Fórmula.
- Variables.
- Unidades.
- Sustitución numérica.
- Interpretación.

## Código

Para cada bloque:

- Lenguaje.
- Propósito.
- Dependencias.
- Explicación.
- Riesgos o errores comunes.
