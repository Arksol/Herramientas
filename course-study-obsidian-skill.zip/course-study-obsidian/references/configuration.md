# Configuración y seguridad

## Ubicación recomendada de la skill en Windows

```text
C:\Users\<usuario>\.codex\skills\course-study-obsidian\
```

Reiniciar Codex después de instalar o actualizar la skill.

## Espacio de trabajo recomendado

```text
C:\Users\<usuario>\Documents\course-study-agent\
├── config.yaml
├── .venv\
├── temp\
└── logs\
```

## Bóveda

Ejemplo:

```text
C:\Users\<usuario>\Documents\Obsidian\MiBoveda
```

No asumir el nombre ni la ruta. Verificar antes de escribir.

## Datos sensibles

Nunca guardar:

- Contraseñas.
- Códigos MFA.
- Cookies.
- Tokens.
- Cabeceras de autenticación.
- Datos académicos innecesarios.
- Calificaciones o información de compañeros en capturas.

Si una herramienta guarda estado del navegador, usar una carpeta privada fuera de Obsidian:

```text
C:\Users\<usuario>\.course-study-agent\auth\
```

Añadir esa carpeta a exclusiones de sincronización y repositorios.

## Convenciones

- Notas: UTF-8.
- Imágenes: PNG o WebP.
- Video autorizado: MP4 cuando la plataforma lo entregue así.
- Nombres: sin `<>:"/\|?*`.
- Fecha: `YYYY-MM-DD`.
- Hora: zona local del usuario.
