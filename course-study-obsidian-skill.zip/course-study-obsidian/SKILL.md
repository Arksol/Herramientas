---
name: course-study-obsidian
description: Automatiza el estudio de cursos en EBAC, UVM Blackboard, Platzi, Coursera y Mastermind: navega páginas autorizadas, recopila títulos, transcripciones, recursos y texto visible, captura diapositivas relevantes, produce resúmenes académicos en Markdown, diagramas Mermaid y mapas conceptuales JSON Canvas, y guarda los resultados en una bóveda local de Obsidian. Usar cuando el usuario pida resumir clases grabadas o en vivo, organizar recursos de un LMS, crear apuntes en Obsidian, tomar capturas mientras estudia o descargar únicamente videos mediante opciones oficiales de EBAC o UVM Blackboard.
---

# Estudio de cursos a Obsidian

## Objetivo

Convertir una clase autorizada en un paquete de estudio local:

- Nota Markdown estructurada.
- Capturas relevantes, no repetitivas.
- Diagrama Mermaid.
- Mapa conceptual `.canvas`.
- Preguntas de repaso.
- Índice del curso actualizado.
- Video descargado solamente cuando EBAC o UVM Blackboard ofrezcan una descarga oficial.

## Recursos incluidos

Leer solamente cuando sea necesario:

- `references/platforms.md`: navegación y reglas específicas de cada plataforma.
- `references/configuration.md`: configuración local, seguridad y estructura de carpetas.
- `references/output-standard.md`: estándar de calidad del resumen.
- `assets/class-note-template.md`: plantilla de la nota.
- `scripts/select_region.py`: selección visual del área de diapositivas.
- `scripts/capture_slides.py`: captura de cambios visuales de una región de pantalla.
- `scripts/assemble_note.py`: ensambla resumen y capturas en una nota.
- `scripts/create_canvas.py`: genera un mapa conceptual JSON Canvas.

## Principios obligatorios

1. Usar únicamente una sesión en la que el usuario haya iniciado sesión legítimamente.
2. Pedir que el usuario realice manualmente inicios de sesión, CAPTCHA, MFA y confirmaciones sensibles.
3. No solicitar, copiar ni guardar contraseñas en chats, archivos de configuración o repositorios.
4. No extraer cookies, tokens, cabeceras de autenticación ni enlaces multimedia temporales.
5. No inspeccionar manifiestos HLS/DASH, archivos `m3u8`, segmentos de video ni DRM.
6. No descargar videos de Platzi, Coursera o Mastermind.
7. En EBAC y UVM Blackboard, descargar un video solamente si aparece una opción oficial y visible de descarga o si el video es un archivo adjunto descargable autorizado.
8. Si no existe descarga oficial, detener esa parte del flujo y continuar con transcripción, resumen, recursos y capturas permitidas.
9. No grabar clases en vivo sin autorización del profesor o de la institución.
10. Mantener las capturas y notas para estudio personal; no republicar materiales protegidos.

## Flujo principal

### 1. Cargar configuración

1. Buscar `config.yaml` en el espacio de trabajo.
2. Si no existe, copiar `config.example.yaml` y solicitar únicamente los valores indispensables:
   - Ruta de la bóveda de Obsidian.
   - Carpeta raíz de cursos.
   - URL inicial de UVM Blackboard.
3. Validar que la bóveda exista.
4. Crear las carpetas indicadas en `references/configuration.md`.
5. Nunca escribir fuera de la bóveda, la carpeta de descargas autorizadas o el espacio de trabajo configurado.

### 2. Identificar plataforma y alcance

Determinar:

- Plataforma.
- Curso.
- Módulo.
- Lección.
- Tipo de contenido: grabación, clase en vivo, lectura, PDF, presentación, recurso o evaluación.
- Qué solicita el usuario: resumen, capturas, recursos, descarga oficial o paquete completo.

Consultar `references/platforms.md` y aplicar el adaptador correspondiente.

### 3. Autenticación controlada

1. Abrir la URL inicial configurada.
2. Si aparece inicio de sesión, permitir que el usuario lo complete.
3. Esperar hasta que el usuario confirme que está dentro del curso.
4. No guardar estado de autenticación dentro de la bóveda ni del repositorio.
5. Si el navegador admite persistencia, almacenarla únicamente en la ruta privada configurada y excluirla de Git.

### 4. Inventariar la clase antes de reproducirla

Recopilar primero:

- Título exacto.
- Curso, módulo y lección.
- Profesor, si aparece.
- Duración.
- Fecha.
- Objetivos.
- Descripción.
- Transcripción o subtítulos disponibles.
- Archivos descargables.
- Enlaces y lecturas.
- Código, fórmulas, cuestionarios y actividades.
- Marca de progreso de la plataforma, sin cambiarla salvo petición expresa.

Guardar un inventario temporal en JSON.

### 5. Prioridad de extracción

Usar este orden:

1. Transcripción oficial o subtítulos visibles.
2. Presentación, PDF, lecturas y archivos del profesor.
3. Texto visible de la página.
4. Capturas de diapositivas relevantes.
5. Transcripción local de un archivo autorizado que el usuario ya posea.
6. Notas manuales proporcionadas por el usuario.

No inventar contenido cuando falte una fuente.

### 6. Capturas eficientes

Objetivo: capturar cambios significativos, no cada segundo del video.

1. Preferir capturas del área de diapositivas, excluyendo subtítulos, controles y rostro del profesor cuando no aporten información.
2. Ejecutar primero `scripts/select_region.py` para guardar `region.json`.
3. Usar `scripts/capture_slides.py --region-file region.json`.
4. Configurar un intervalo de 2 a 5 segundos.
5. Guardar una imagen solamente cuando el hash perceptual cambie por encima del umbral.
6. Eliminar capturas negras, borrosas, duplicadas o dominadas por controles.
7. Conservar normalmente entre 3 y 20 capturas por lección.
8. Renombrar:
   - `001-concepto-principal.png`
   - `002-diagrama-arquitectura.png`
   - `003-ejemplo-codigo.png`
9. Incluir una breve leyenda y el minuto aproximado cuando esté disponible.

### 7. Descarga autorizada

Aplicar solamente a EBAC y UVM Blackboard.

Se permite:

- Pulsar un botón oficial visible llamado `Descargar`, `Download` o equivalente.
- Descargar un archivo MP4 adjunto mediante el enlace que la propia plataforma presenta como descargable.
- Descargar recursos PDF, PPTX, DOCX, ZIP, código o plantillas ofrecidos oficialmente.

No se permite:

- Buscar la URL real del reproductor.
- Interceptar tráfico de red.
- Reutilizar cookies o tokens.
- Convertir transmisiones protegidas en archivos.
- Evitar restricciones de la plataforma.

Registrar:

- Nombre del archivo.
- Tamaño, si está disponible.
- Fuente.
- Fecha.
- Estado: `descargado-oficialmente` o `sin-opcion-oficial`.

### 8. Analizar y resumir

Seguir `references/output-standard.md`.

Generar:

- Resumen ejecutivo.
- Resumen detallado por secciones.
- Definiciones.
- Procedimientos.
- Ejemplos.
- Fórmulas con variables y unidades.
- Código con lenguaje identificado.
- Errores frecuentes.
- Glosario.
- Preguntas de repaso.
- Ejercicio práctico.
- Conclusiones.
- Fuentes exactas usadas.

Distinguir con etiquetas:

- `Fuente de la clase`
- `Explicación complementaria`
- `Inferencia`

### 9. Crear visualizaciones

Crear dos formatos:

#### Mermaid

Incluir un diagrama compatible con Obsidian:

```mermaid
flowchart TD
  A[Concepto principal] --> B[Subconcepto]
  A --> C[Aplicación]
```

No crear diagramas decorativos. Deben representar relaciones reales.

#### JSON Canvas

1. Preparar un JSON de conceptos y relaciones.
2. Ejecutar `scripts/create_canvas.py`.
3. Crear `<nombre-leccion>-mapa.canvas`.
4. Incluir la nota principal y las capturas más importantes como nodos de archivo.
5. Verificar que todos los nodos y conexiones sean legibles.

### 10. Guardar en Obsidian

Usar esta estructura:

```text
Cursos/
└── Plataforma/
    └── Curso/
        ├── 00-Índice.md
        ├── Módulo-01/
        │   ├── 01-Nombre-de-la-clase.md
        │   ├── 01-Nombre-de-la-clase-mapa.canvas
        │   └── adjuntos/
        │       ├── capturas/
        │       └── recursos/
        └── _descargas-autorizadas/
```

Reglas:

- Usar rutas relativas en enlaces y embeds.
- No sobrescribir una nota sin crear una copia o confirmar.
- Mantener nombres de archivo seguros para Windows.
- Actualizar `00-Índice.md`.
- Añadir enlaces `[[...]]` a conceptos relacionados.
- Abrir la nota mediante Obsidian URI cuando sea útil.

### 11. Control de calidad

Antes de terminar:

- Confirmar que el resumen coincide con las fuentes.
- Revisar que ninguna sección haya sido inventada.
- Verificar que las capturas existan y no estén duplicadas.
- Validar el JSON del archivo `.canvas`.
- Comprobar enlaces internos.
- Confirmar que no se descargó contenido de plataformas no permitidas.
- Informar qué no pudo recopilarse y por qué.

## Comportamiento por plataforma

- EBAC: resumen completo, recursos, capturas y descarga oficial si existe.
- UVM Blackboard: resumen completo, recursos, capturas y descarga oficial si existe.
- Platzi: resumen, recursos y capturas; nunca descargar video.
- Coursera: resumen, transcripción, recursos y capturas; nunca descargar video.
- Mastermind: resumen, recursos y capturas; nunca descargar video.

## Órdenes de ejemplo

- `Resume la clase actual de EBAC y guárdala en Obsidian con capturas y mapa conceptual.`
- `Analiza el módulo 2 de Coursera. No descargues videos.`
- `Recopila los recursos de esta clase de Blackboard y descarga el video solo si existe un botón oficial.`
- `Mientras reproduzco la clase, captura únicamente los cambios importantes de las diapositivas.`
- `Actualiza el índice del curso y genera preguntas de repaso.`
